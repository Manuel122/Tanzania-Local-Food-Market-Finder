# Tanzania Local Food Market Finder

An open-source web app that maps and lists Tanzanian markets with details like location, specialties, and opening hours.

## Features
- Interactive map of Tanzanian markets
- Market info: name, city, specialties, hours
- JSON API to add more markets

## Setup
1. Clone the repo  
   ```bash
   git clone https://github.com/yourusername/tanzania-market-finder.git
   cd tanzania-market-finder
   ```

2. Install dependencies  
   ```bash
   pip install -r requirements.txt
   ```

3. Run the app  
   ```bash
   python app.py
   ```
   Open in browser: `http://127.0.0.1:5000`

## Contributing
- Add new markets to `data/markets.json`  
- Suggest new features via pull requests  
- Report issues on GitHub

## License
MIT License