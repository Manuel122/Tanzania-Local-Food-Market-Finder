from flask import Flask, render_template, jsonify
import json
import os

app = Flask(__name__)

with open(os.path.join("data", "markets.json"), "r", encoding="utf-8") as f:
    markets = json.load(f)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/markets")
def get_markets():
    return jsonify(markets)

if __name__ == "__main__":
    app.run(debug=True)