let map = L.map('map').setView([-6.8, 39.28], 6);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

fetch("/api/markets")
  .then(response => response.json())
  .then(data => {
    data.forEach(market => {
      L.marker([market.lat, market.lng])
        .addTo(map)
        .bindPopup(`<b>${market.name}</b><br>${market.city}<br>${market.opening_hours}<br><i>${market.specialties.join(", ")}</i>`);
    });
  });